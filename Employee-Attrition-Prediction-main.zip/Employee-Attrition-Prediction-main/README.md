# Employee-Attrition-Prediction

## Objective:
In this project we have HR data of a company. A study is requested from us to predict which employee willchurn by using this data.
The HR dataset has 14,999 samples. In the given dataset, we have two types of employee one who stayed andanother who left the company.

## Tools used:

- GradientBoostClassifier
- kNN
- RandomForestClassifier

- Jupyter Notebook for ML Model
- Streamlit for WebApp
